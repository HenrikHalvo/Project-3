package no.hvl.dat110.util;


/**
 * exercise/demo purpose in dat110
 * @author tdoy
 *
 */

public class StaticTracker {
	public static String[] ACTIVENODES = {"process1:9091"};	// we will implement this as a tracker  
}
